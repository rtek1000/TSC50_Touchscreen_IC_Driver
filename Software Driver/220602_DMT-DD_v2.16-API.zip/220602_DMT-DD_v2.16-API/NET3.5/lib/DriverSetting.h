﻿ 
/**
 * @file DriverSetting.h
 * @brief Libとして公開するAPI
 *
 * @date  2015/05/11 doxygenに対応
 * @author Daisuke Uchida
 */

#ifndef	_DRIVERSETTING_H_
#define	_DRIVERSETTING_H_


typedef struct CORRECTION {
	USHORT p00x; /** @brief p00 X 座標 (4 点/9 点) 0～32767*/
	USHORT p00y; /** @brief p00 Y 座標 (4 点/9 点) 0～32767*/
	USHORT p10x; /** @brief p10 X 座標 (4 点/9 点) 0～32767*/
	USHORT p10y; /** @brief p10 Y 座標 (4 点/9 点) 0～32767*/
	USHORT p01x; /** @brief p01 X 座標 (4 点/9 点) 0～32767*/
	USHORT p01y; /** @brief p01 Y 座標 (4 点/9 点) 0～32767*/
	USHORT p11x; /** @brief p11 X 座標 (4 点/9 点) 0～32767*/
	USHORT p11y; /** @brief p11 Y 座標 (4 点/9 点) 0～32767*/
	USHORT p20x; /** @brief p20 X 座標 (9 点) 0～32767*/
	USHORT p20y; /** @brief p20 Y 座標 (9 点) 0～32767*/
	USHORT p21x; /** @brief p21 X 座標 (9 点) 0～32767*/
	USHORT p21y; /** @brief p21 Y 座標 (9 点) 0～32767*/
	USHORT p02x; /** @brief p02 X 座標 (9 点) 0～32767*/
	USHORT p02y; /** @brief p02 Y 座標 (9 点) 0～32767*/
	USHORT p12x; /** @brief p12 X 座標 (9 点) 0～32767*/
	USHORT p12y; /** @brief p12 Y 座標 (9 点) 0～32767*/
	USHORT p22x; /** @brief p22 X 座標 (9 点) 0～32767*/
	USHORT p22y; /** @brief p22 Y 座標 (9 点) 0～32767*/
}Correction, *PCorrection;


extern USHORT GetTouchDeviceCount(void);
extern int GetTouchDeviceInstancePath(USHORT no, char *DeviceInstancePath);
extern int ExecuteCalibration(char *DeviceInstancePath);
extern int ExecuteCalibration9point(char *DeviceInstancePath);
extern int ClearCalibration(char *DeviceInstancePath);
extern int ExecuteMonitorMapping(char *DeviceInstancePath);
extern int ClearMonitorMapping(char *DeviceInstancePath);
extern int SetTouchEnable(char *DeviceInstancePath, bool flg);
extern int GetTouchEnable(char *DeviceInstancePath);
extern int GetTouchDeviceState(char *DeviceInstancePath);
extern int ResetTouchDevice(char *DeviceInstancePath);
extern int GetAttachedMonitorSymbol(char *DeviceInstancePath, char *MonitorSymbol);
extern int SetAttachedMonitorSymbol(char *DeviceInstancePath, char *MonitorSymbol);
extern int RegisterTouchEventNotify(char *DeviceInstancePath, HWND handle);
extern int GetEEPROM(char *DeviceInstancePath);
extern int SetEEPROM(char *DeviceInstancePath, bool state);
extern int SetEnableRightClick(char *DeviceInstancePath, int flg, int PressAndHoldTime, int PressAndHoldRange);
extern int GetEnableRightClick(char *DeviceInstancePath, int *PressAndHoldTime, int *PressAndHoldRange);
extern int SetOutPutRate(char *DeviceInstancePath, int iRate);
extern int GetOutPutRate(char *DeviceInstancePath);
extern int DirectCommand(char *DeviceInstancePath, unsigned char *Command, int Size);
extern int DirectRequest(char* DeviceInstancePath, unsigned char* Data, int Size, int Timeout);
extern int DirectCommunication(char* DeviceInstancePath, int State);
extern int SetInvertedX(char *DeviceInstancePath, bool flg);
extern int GetInvertedX(char *DeviceInstancePath);
extern int SetInvertedY(char *DeviceInstancePath, bool flg);
extern int GetInvertedY(char *DeviceInstancePath);
extern int SetSwapXY(char *DeviceInstancePath, bool flg);
extern int GetSwapXY(char *DeviceInstancePath);
extern int GetCalibrationInfomation(char *DeviceInstancePath, Correction* correction, Correction* ideal);
extern int SetComPortNo (char *DeviceInstancePath, int comport);
extern int GetComPortNo (char *DeviceInstancePath);
extern int SerialDeviceEnable (char *DeviceInstancePath, BOOL enable);
extern int SetConfig (char *DeviceInstancePath, char *ConfigFileName);
extern int GetConfig (char *DeviceInstancePath, char *ConfigFileName);
#endif	//	_DRIVERSETTING_H_

