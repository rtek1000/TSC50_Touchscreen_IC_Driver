The basic set up necessary before using the driver is as follows.


1. For Japanese language, execute [DMT-DDSetup.msi] in [jp] folder to install the DMT-DD driver software.
�@ For English language, execute [DMT-DDSetup.msi] in [en] folder to install the DMT-DD driver software.
   (Execute [DMT-DDSetup.msi] for WindowsXP/7/8/8.1   /   Execute [DMT-DDSetup_ms.msi] for Windows10.)

2. Start DMT-DD via shortcut on desktop.

3. Perform [Monitor Configuration] and [TabletPC Setting] as referring to the [User's Guide], in order to link the touch sensors with monitors.
�@�@Making link between sensor and monitor is necessary regardless of whether it is single-monitor or multiple-monitors

4. If the touch screen is resistive, perform calibration to correct touch positions.
�@�@For this calibration, open [Basic Setting] and click either [4point] or [9point] under [Calibrate]. 
�@�@The calibration screen will appear. Touch on each calibration point to complete calibration.  

�@�@For a capacitive touch screen, calibration for positioning correction is no necessary. 
    On the other hand, it requires adjustment for environmental noise. Open [Basic Setting] and click [Open] under[Touch Screen Maintenance]
    to perform environmental adjustment.

Once 1. to 4. above were done, the basic set up has been completed.
