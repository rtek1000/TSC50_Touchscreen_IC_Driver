***************************************************************************************
*                            DMC-Touch-Panel Driver
*
*                            TSC-10/LD Version2.1.5
*
*                            Rev.A    October 29, 2013
*
***************************************************************************************

*DMC Co., Ltd does not provide technical support, a maintenance, etc to this driver
 software and this document.
 DMC will not be liable for any damage and loss caused by the use of this software. DMC
 will not be liable for any type of compensation.
 This software is subject to change without notice.

***************************************************************************************
1.OUTLINE
***************************************************************************************
	The TSC-10/LD mouse emulation software lets you use our touch screen
	controller, the TSC-**/IC just as though you were using 
	a mouse by operating the touch screen.
	Mouse operation is emulated as a xinput driver of XWindow system.
	This book is an instructions manual of setting programs, such as a driver and
	a calibration, etc.

	By XF86Config and/or xorg.conf setting, operation by either USB or RS-232C 
        communication is possible.
        From Version 1.1.5, the filter driver is intervened between the USB driver and
	the XWindow, in order to add PnP function of USB interface. 

	This driver supports multi-touch screen. Please refer to multi_e.txt for use.

	�EUSB
		+---------------------------------------------+
		|     �@  XWindow(XFree86 or Xorg)            |
		+------------------------------------+        |
		|     XINPUT driver  dmc_drv.o       | <--Above XWindow6.9, it is dmc_drv.so
		+------------------------------------+--------+
		|                       OS                    |
		+------------------------------------+        |
		|     Filter driver  tpdmc.o         | <--If Kernel2.6, it is tpdmc.ko
		|		touch0		     |	      |
		+------------------------------------+        |
		|     usb driver      usbdmc.o       | <--In Kernel2.6, it is usbdmc.ko
		|		dmc0		     |	      |
		+------------------------------------+--------+
		|                       HW                    |
		+---------------------------------------------+
	
	�ERS-232C
		+---------------------------------------------+
		|     �@�@XWindow (XFree86 or Xorg)           |
		+------------------------------------+        |
		|     XINPUT driver  dmc_drv.o       | <--XWindow6.9 or above, it is dmc_drv.so
		+------------------------------------+--------+
		|                       OS                    |
		+------------------------------------+        |
		|          RS-232C driver            |        |
		+------------------------------------+--------+
		|                       HW                    |
		+---------------------------------------------+
	
		*RS-232C driver can communicate by the tty driver of OS attachment.

***************************************************************************************
2.SPEC
***************************************************************************************
	Correspondence
		USB (USB Specification 1.1 Low Speed)
		Asynchronous Serial (RS-232C)

	Setting program
		(1)Calibration
			2/3/4/5/9 points
		(2)Coordinate output rate (point/sec)
			30 p/s
			50 p/s
			80 p/s
			100 p/s
			130 p/s
			150 p/s
			Point Mode (Only Touch down/up, no movement)
		(3)Beep sound
			Touch down beep ON/OFF
			Touch up beep ON/OFF
		(4)Liftoff Delay (for USB only)
			0ms/10ms/20ms/....../100ms

	XINPUT Driver
		(1)By the xinput specification driver of a XWindow system, touch input
		   is outputted as mouse input. Of course, the concurrent use with 
		   a mouse is possible.
		(2)A calibration data is saved in following order.
			EEPROM on a controller
			"dmc_calib.dat" file
		     *Error data are disregarded.
		(3)The "dmc_calib.dat" file can be specified with a directory 
		   in XF86Config.
		(4)When a driver (XWindow) starts up, calibration data are read
		   in following order.
			"dmc_calib.dat" file
			EEPROM on a controller
		     *It is used giving priority to the data in EEPROM.

	USB Filter Driver
		(1)The USB filter driver is used from a XINPUT driver and communicates
		   with USB driver. This driver also executes the PnP control.
		     *You have to load the USB filter driver, before starting XWindow.
		(2)Since the USB filter driver is a kernel driver, it is dependent on 
                   a kernel version.
	           Therefore, it is necessary to recompile the USB filter driver 
		   in user's environment.
        
        USB Driver 
                (1)The USB driver is used from the USB filter driver and communicates
		   with touch screen.
                        *You have to load the USB driver, before starting XWindow.
                (2)Since the USB driver is a kernel driver, it is dependent on a kernel
		   version. 
                   Therefore, it is necessary to recompile the USB filter driver
		   in user's environment.      

***************************************************************************************
3.Development / Checking of operations environment
***************************************************************************************
	Development environment
        This driver is developed under the environments stated as below. 
		CPU		AthlonXP
		Distribution	Fedora7
		Kernel		Kernel-2.6.21-1.3194.fc7.i686
	Checking environment
        This driver is checked under the environments stated as below.
		CPU		x86 architecture
				  AthlonXP

		*Re-conpile is required for a USB driver.
		*A USB driver does not work with kernel 2.6.1 to 2.6.9.
		--------+---------------------------------------------
			| kernel	XWindow		Xinput ABI
		--------+---------------------------------------------
		Fedora4	| 2.6.11	6.8.2		0.4
		Fedora7	| 2.6.21	1.3.0		0.7
		Fedora10| 2.6.27	1.5.3		2.1
		Fedora11| 2.6.29	1.6.1		4
		Fedora12| 2.6.31	1.7.1		4
		fedora13| 2.6.33	1.8.0		9 
		fedora14| 2.6.35	1.9.0		11
		fedora15| 2.6.38	1.10.1		12.2
		fedora16| 3.1.0		1.11.1		13
		fedora17| 3.3.4		1.12.0		16
		fedora18| 3.6.10	1.13.3		18
		fedora19| 3.9.5		1.14.1		19.1
		------------------------------------------------------
		*The binary that we confirmed in each distribution in a "dist" directory
		 is stored.
                *In case of no beep sound(including keyboard inputs), the beep sound 
		 can be activated by executing # /sbin/modprobe pcspkr after starting 
		 the OS(AT-compatible).
                 You can also write it in rc.local.
		*The version of XWindow shows a version of XSERVER above FC8.


***************************************************************************************
4.Exposition of file
***************************************************************************************
	Please expand tsc_xxx_YYMMDD.tgz by the arbitrary directories on Linux.
	The contents are as follows.

	   [TSC10LD_Vxxx] 		<---'xxx' is a version number
	     |
	     +-- XF86Config             XF86Config sample
	     +-- dmc_calib.dat          Initial data sample of a calibration
	     +-- objinstall             The batch file for object installation
	     |
	     +-- [driver]               --- Driver directory ---
	     |      |
	     |      +-- makefile
	     |      +-- xf86DMC.h       Driver header
	     |      +-- xf86DMC.c       Driver source
	     |      +-- dmc_drv.o       Driver
	     |
	     +-- [usb]			--- USB driver directory (kernel 2.4) ---
	     |	    |
	     |	    +-- makefile
	     |      +-- <usbdmc.h>      Driver header:usb26/usbdmc.h is used.
	     |      +-- <usbdmc.c>      Driver source:usb26/usbdmc.c is used.
	     |      +-- usbdmc.o        Driver
	     |
	     +-- [usb26]		--- USB driver directory (kernel 2.6) ---
	     |	    |
	     |	    +-- makefile
	     |      +-- usbdmc.h        Driver header
	     |      +-- usbdmc.c        Driver source
	     |      +-- usbdmc.o        Driver
	     |
	     +-- [tbctl]                --- Setting program directory ---
	            |
	            +-- makefile
	            +-- tb.h            header
	            +-- tbctl.c         Main program source
	            +-- tbcalib.c       Calibration program source
	            +-- tbtest.c        Touch input trace test program source
	            +-- tbselector.c    Button selector program source
	            +-- ulib.c          Library for XWindow
	            +-- xilib.c         xinput interface library
	            +-- tbctl           Main execution object
	            +-- tbcalib         Calibration execution object
	            +-- tbtest          Touch input trace test execution object
	            +-- tbselector      Button selector execution object
         
          *In tsc_xxx_dist_YYMMDD.tgz, the USB driver binary of each distribution is stored. 

	   [distXXX]		<---'xxx' is a version number
	     |
	     +-- readme.txt            
	     |
	     +-- [fc7]		---Binary of Fedora7---
		 :
		 :
        If it is a different distribution, the USB driver needs to be recompiled, 
        please refer to the remarks 3. 

***************************************************************************************
5.Execution
***************************************************************************************
	It is possible to use the USB driver as it is, if the distribution can use 
        the binary stored in the [dist] directory stated above. 
        If it is a different distribution, the USB driver needs to be recompiled, 
        please refer to the remarks 3. 
	Please refer to the remarks 2, if compiling is required.

	*Operate by root user.
	*Please delete "usbtouchscreen.ko" loaded at the time of the start of the
	 system. Because a usb driver competes. 
		/lib/modules/2.6.xxx/kernel/drivers/usb/input/
	 Please reboot a system after having deleted it.
			cat /proc/modules
	 You can confirm whether it is loaded in this.
	*In the case of Fedora8, the XINPUT driver is an access permission error by
	 selinux. It did not have this problem until Fedora7.
				/etc/selinux/config
					�F
					SELINUX=eonforcing
		You need to change "enforcing" to "disable". Or to chage setting of
		selinux.

	(1)In USB operation, USB device is created and it loads USB driver.
		kernel2.4
			$ cd /dev
			$ mknod touch0 c 200 1             ...create device
			$ cd /dev/usb
			$ mknod dmc0 c 180 181             ...create device
			$ cd <TSC10LD_Vxxx>/usb
			:
			Compile
			:
			$ insmod tpdmc.o                   ...load
			$ insmod usbdmc.o                  ...load

	  	�Ekernel2.6
			$ cd <TSC10LD_Vxxx>/usb26
			:
			Compile
			:
			$ mknod /dev/touch0 c 200 1        ...create device
			$ insmod tpdmc.ko                  ...load
			$ insmod usbdmc.ko                 ...load
		    
                    In fedora2, dmc0 cannot be created automatically. Therefore 
                    please execute the following commands.
			�@�@$ cd /dev/usb
			�@�@$ mknod dmc0 c 180 181             ...create device
           
           When loading is successful, the below messages will be indicated in 
           the system console.
			DMC Touch Panel Filter Driver Ver.x.x.x Major=200
			DMC USB-Driver Vx.x.x
			usbdmc_probe vendor=$afa prduct=$3e8
			usmdmc_probe: endpoint ieq-in 1 ,interval=1
           In case of not using system console, the messages can be checked 
           by dmesg command.

	(2)Please copy the object in the uncompressed file to a predetermined 
	   directory.
           * Before Fedora5
	   A batch file named "objinstall" is prepared.

			object            	directory
			----------------------------------------------------------
			dmc_drv.o               /usr/X111R6/lib/modules/input
			tbctl                   /usr/X11R6/bin
			tbcalib                 /usr/X11R6/bin
			tbtest                  /usr/X11R6/bin
			tbselector              /usr/X11R6/bin

	   * Fedora5 or above
	   A batch file named "objinstall3" is prepared. 

			Object                  directory
			----------------------------------------------------------
			dmc_drv.so              /usr/lib/xorg/modules/input
			tbctl                   /usr/bin
			tbcalib                 /usr/bin
			tbtest                  /usr/bin
			tbselector              /usr/bin

		*If tbctl, tbcalib, tbtest, and tbselector are directory which specify 
		 the execution pass, they do not need to be /usr/bin.
		*When it is 64bit environment, it may be /usr/lib64 not /usr/lib.

	(3)Please refer to XF86Config and correct /etc/X11/XF86Config.

	   *It will correct /etc/X11/XF86Config-4 if it is Vine2.6.
	    That is, please correct XF86Config which XWindow uses.
            In case of Fedora Core2 onwards, please correct xorg.conf.
	   *Please refer to remarks 7.

	  Registration as a pointer device.
	   		Section "ServerLayout"
			   Identifier     "Anaconda Configured"
			   Screen         0  "Screen0" 0 0
			   InputDevice    "Mouse0" "CorePointer"
			   InputDevice    "Touch" "SendCoreEvents"    <--- Addition
			   InputDevice    "Keyboard0" "CoreKeyboard"
			EndSection

			*It will not work as CorePointer.
			*Identifier for InputDevice have to be the same as 
                         the identifier for Section "InputDevice". 
			   �@�@�@�@InputDevice    "Touch" "SendCoreEvents"
			   �@�@�@�@�@�@�@�@�@�@�@�@�@��
			   �@�@�@�@�@�@�@�@�@�@�@�@Identifier

	   USB=Device is added.
		kernel2.4
		  Section "InputDevice"
		    Identifier  "Touch"
		    Driver      "dmc"
		    Option      "USB"  "1"
		    Option      "Device" "/dev/touch0" ...The device name created by(1)
		    Option      "SaveFile" "/etc/X11/dmc_calib.dat"
		    Option      "ApiDir" "/tmp"
		  EndSection
		kernel2.6
		  Section "InputDevice"
		    Identifier  "Touch"
		    Driver      "dmc"
		    Option      "USB"  "1"
		    Option      "Device" "/dev/touch0" ...The device name created by(1)
		    Option      "SaveFile" "/etc/X11/dmc_calib.dat"
	            Option      "ApiDir" "/tmp"
		  EndSection
			
	    RS-232C=Device is added
		  Section "InputDevice"
		    Identifier  "Touch"
		    Driver      "dmc"
		    Option      "Device"  "/dev/ttyS0"   ...Connection serial port
		    Option      "SaveFile" "/etc/X11/dmc_calib.dat"
	            Option      "ApiDir" "/tmp"
		  EndSection

	(4)Please copy dmc_calib.dat in the uncompressed file to /etc/X11.
	   And, correct if needed.
	   Please refer to a remarks 1 for details.

			# ---------------------------------
			# DMC-Touch-Panel setup
			# ---------------------------------
			PenDownBeep  1
			PenUpBeep    1
			SamplingRate 0
			# ---------------------------------
			# raw data
			# ---------------------------------
			RawX0   56
			RawY0   65
			RawX1   919
			RawY1   929
			# ---------------------------------
			# calibration data
			# ---------------------------------
			CalX0   25
			CalY0   25
			CalX1   999
			CalY1   743

	(5)If XWindow is restarted, a driver will operate.
	   *When a touch screen does not operate, the power source of a touch screen
	    controller is re-switched on and please restart a system.

	(6)If touch input is possible, in "$tbctl", please start a setting program and
	   perform the calibration of a touch screen.
	   *If tbctl does not start, you refer to remarks 2, and please recompile a program.
 
        (7)If a touch screen operates normally, please enable the automatic loading at
            the time of start, if necessary. 
            For example: In order to load automatically, please write the followings 
                         in /etc/rc.d/rc.sysinit. 
			   mknod /dev/touch0 c 200 1
	   		   insmod /xxxx/xxxx/tpdmc.o <--If kernel2.6, it is tpdmc.ko
	   		   insmod /xxxx/xxxx/usbdmc.o <--If kernel2.6, it is usbdmc.ko                   
            

***************************************************************************************
6.Setting program
***************************************************************************************
	6-1.tbctl
		Executing of "tbctl" displays the following main windows.
		Each button is clicked and each function is performed.
		*If tbctl does not start, you refer to remarks 2, and please recompile
		 a program.

	             +----------------------------------------------------+
	             | TSC-10/LD Control Main                             |
	             +----------------------------------------------------+
	             |                                         Ver1.x.x   |
	             | < Sampling Rate >        < Sound >                 | 
	             |    ��  30 p/s         �� Touch Down Beep on        |
	             |    ��  50 p/s         �� Touch Up Beep on          |
	             |    ��  80 p/s           <Liftoff Delay >           |
	             |    �� 100 p/s      �� 0msec  �� 40msec �� 80msec   |
	             |    �� 130 p/s      �� 10msec �� 50msec �� 90msec   |
	  	     |    �� 150 p/s      �� 20msec �� 60msec �� 100msec  |
	  	     |    �� Point Mode   �� 30msec �� 70msec             |
		     | +---------------------+ +------------------------+ |
		     | |        Apply        | |       Test...        	| |
		     | +---------------------+ +------------------------+ |
		     | +---------------------+				  |
		     | |    Run Selector     |				  |
		     | +---------------------+				  |
		     |							  |
		     | < Calibration Points > < Calibration Time Out >    |
	             |    �� 2 point            �� 10 sec                 |
	             |    �� 3 point            �� 20 sec                 |
	             |    �� 4 point            �� 60 sec                 |
	             |    �� 5 point					  |
		     |	  �� 9 point					  |
	             | +------------------------------------------------+ |
	             | |               Calibration...                   | |
	             | +------------------------------------------------+ |
		     +----------------------------------------------------+

		< Sampling Rate >
		Coordinate output rate. (point/sec)

		< Sound >
		Enable or disable the Sound option that accompanies simulated 
		touch screen presses.

		<Liftoff Delay>
		The pen up data packet is used to invoke pen up otherwise the pen up 
		processing will generate a pen up event at the time threshold.

		< Apply >
		Applies all changes.

		< Test >
		Invokes the pointing device test utility. (tbtest)

		< Run Selector >
		Invokes button selector utility. (tbselector)

		< Calibration Points >
		Specifies the number of calibration points to be used.

		< Calibration Time Out >
		Indicates the calibration timeout value if the calibration point is not
		touched within the specified period. Defined in seconds.

		< Calibration >
		Invokes the calibration procedure. (tbcalib)

	6-2.tbcalib
		Once invoked the calibration screen is displayed requesting that
		each calibration point be selected in turn.

         +----------------------------------------------------------------------+
         | �{                                                                   |
         |                                                                      |
         |                                                                      |
         |           Executing Calibration. Please touch mark!!                 |
         |           TIME-OUT = 10 sec                                          |
         |                                                                      |
         |                                                                      |
         |                                                                      |
         |                                                                      |
         |                                                                      |
         |                                                                      |
         |                                                                      |
         |                                                                      |
         |                                                                      |
         |                                                                      |
         +----------------------------------------------------------------------+


		The dialog of calibration completion.
			+-----------------------------+
	       	        | TSC-10/LD-Clibration Result |
			+-----------------------------+
			|   Saved Calibration Data!!  |
			|    +-------+   +------+     |
			|    |  OK   |   |Cancel|     |
			|    +-------+   +------+     |
			+-----------------------------+

		Selection of the OK button saves calibration data to EEPROM
		and dmc_calib.dat file.
		Failure to select the OK button within a certain time will result 
		in the new calibration data being discarded.

		The dialog of calibration timeout.
			+-----------------------------+
	        	| TSC-10/LD-Clibration Result |
			+-----------------------------+
			|                             |
			|   Calibration Time Out!!    |
			|                             |
			+-----------------------------+

		When the calibration point is not touched within the specified period,
		the calibration data are not saved.

	6-3.tbselector
		The button mode of touch input can be changed.
		If tbselector is executed, the "SELECTOR" window will open.
			+------------+
	        	| SELECTOR |X|
			+---+---+----+
			| L | M | R  |
			+---+---+----+

		The L/M/R button is equivalent to the Left/Middle/Right button 
		of a mouse.
		By default, the SELECTOR automatically switches back to the Left button
		after a single Middle or Right button action has been performed.

		*A display position and window size can be changed with the parameter
		 when executing tbselector.
		     tbselector <x> <y> <size-x> <size-y>
		      parameter:<x>      x-coordinate of window display starting point.
		  	        <y>      y-coordinate of window displya starting point.
				<size-x> Window size of the horizontal direction.
				<size-y> Window size of the vertical direction.
		(Example)When a screen is 1280x1024, the window is displayed 
			 on the lower right as a window size of 100x100.
				$ tbselector 1180 924 100 100
				$

***************************************************************************************
Remarks 1.  Calibration data file
***************************************************************************************
	The initial value of calibration data is specified. This file is read 
	at the time of driver (XWindow) starting. 

	*The dirver always gives priority to the EEPROM data.

	Format
		<id-string>  <num>
		Between <id-string> and <num>, one or more spaces are required.

		<id-string>
			PenDownBeep
				Enables or Disables the sound of Pen Down Beep.
					0=Disable
					1=Enable
			PenUpBeep
				Enables or Disables the sound of Pen Up Beep.
					0=Disable
					1=Enable
			SamplingRate
				The sampling rate of coordinates is chosen.
					0=30 p/s
					1=50 p/s
					2=80 p/s
					3=100 p/s
					4=130 p/s
					5=150 p/s
					6=point mode
			Liftoff Delay
				Delay time of the liftoff event
				0=Disable
				10 - 100ms=liftoff time threshold
			RawXn/Yn
				Coordinate for each calibration X/Y-axis calibration 
				point where 'n' is within the range 0-8 for each 
				configured calibration point.
			CalXn/Yn
				Calibration reference points, define the placement 
				of the points using a coodinate based at top left.

	(Example) *"#" of the sentence recognizes the line as a comment.
		# ---------------------------------
		# DMC-Touch-Panel setup
		# ---------------------------------
		PenDownBeep  1
		PenUpBeep    1
		SamplingRate 0
		Liftoff Delay 30
		# ---------------------------------
		# raw data
		# ---------------------------------
		RawX0   56
		RawY0   65
		RawX1   919
		RawY1   929
		# ---------------------------------
		# calibration data
		# ---------------------------------
		CalX0   25
		CalY0   25
		CalX1   999
		CalY1   743

***************************************************************************************
Remarks 2.  Method of compile of XINPUT driver / setting program
***************************************************************************************
	It compiles in the environment which can compile the application of XWindow.
	Please copy directory to arbitrary location.
        Please refer to 5.Execution (1) for where to copy the file.

	Setting program
		(1)It moves to copied tp/tbctl and compiles.
			$ make

		Notice:In FedoraCore9 (above Xorg-server1.4), please change xilib.c
			as follows.
			�@�@	#if 1	 <------Change here to "1".
			�@�@	#define	XVERS14	   1
			�@�@	#endif

		(2)tbctl, tbcalib and tbtest are copied.
			$ cp -pf tbctl tbcalib tbtest /usr/X11R6/bin
		(3)tbctl is executed.
			$ tbctl

	------------------------------------------------
	driver (Do not use rpm source)
	------------------------------------------------
		(1)The header file included in the XWindow source is required.
		   Either expand the XWindow source included in the distribution 
                   or download the source of a corresponding version from the links 
                   stated as below.
			�@http://xfree.org/
			�@http://x.org
		(2)Please expand the downloaded XWindow source to /usr/X11R6/.

		   Example�FIn case of V4.2.0 from http://xfree.org/,
		   			X420src-1.tgz
		   			X420src-2.tgz
		   			X420src-3.tgz
		�@�@�@downlaod those three files to /home/temp/ and execute them 
                      as follows.
		�@�@�@
		�@�@�@	$ cd /usr/X11R6
		�@�@�@	$ tar xvzf /home/temp/X420src-1.tgz
		�@�@�@	 :
		�@�@�@	$ tar xvzf /home/temp/X420src-2.tgz
		�@�@�@	 :
		�@�@�@	$ tar xvzf /home/temp/X420src-3.tgz
		�@�@�@	 :
		�@�@�@	$ 

		(3)It moves to copied tp/driver and compiles.
			$ make		
		(4)dmc_drv.o is copied.
			$ cp -pf dmc_drv.o /usr/X11R6/lib/modules/input
			
			*Directory is different in fedora5 or above.

		*To /usr/X11R6/xc/programs/Xserver/hw/xfree86/input/dmc
		 of the expanded XWindow source, you may copy and compile xf86DMC.c
		 and xf86DMC.h.
		*When using USB interface, USB driver must be loaded before starting
		 XWindow.
		*In Redhat8, when compiling xinput driver, unless it removes of 
		 the following comments in driver/Makefile and carries out "make",
		 it does not operate normally.
				MODULE_GCC_FLAGS=#-fno-merge-constants
						 |---This is removed.

	------------------------------------------------
	driver (Fedora7 = Use rpm source)
	------------------------------------------------
		(1)Install following rpm.
				xorg-x11-server-sdk
		*There is not xorg-x11-server-sdk in Fedora13.
		 Therefore, it may be necessary for you to add the following.
				gcc
				kernel-PAE-devel
				libX11-devel
				libXi-devel
		*There is not xorg-x11-server-sdk in Fedora14.
		 Therefore, it may be necessary for you to add the following.
				xorg-x11-server-devel

		(2)Untar following rpm source.
				xorg-x11-drv-dmc
			example)
				# rpm -Uvh xorg-x11-drv-dmc-1.1.0-3.fc7.src.rpm
				# cd /usr/src/redhat/SPECS
				# rpmbuild -bp --target=`uname -m` xorg-x11-drv-dmc.spec
			*In FC11, xorg-x11-drv-dmc has disappeared. However, it can substitute the file of FC10. 
			*FC11 or above, xorg-x11-drv-dmc has disappeared. However, xorg-x11-drv-dmc equivalency 
			 is included in a dist directory.
		(3)Work with a directory of (2).
		(3-1)Execute configure
				# cd /usr/src/redhat/BUILD/xf86-input-dmc-1.1.0
				# ./configure
		(3-2)Copy the following files in src.
				<TSC10LD_Vxxx>/driver/cmd.h
				<TSC10LD_Vxxx>/driver/xf86DMC.h
				<TSC10LD_Vxxx>/driver/xf86DMC.c
			In Fedora5 and 6, copy the following files also.
				<TSC10LD_Vxxx>/driver/n_xf86_libc.h
		(3-3)Change "#if 0" of src/xf86DMC.c in "#if 1".
				#if 1
				#define	XORG_NEWVERS0		0  <--Fedora5/6 (XWindow 7.x)
				#define	XORG_NEWVERS		1  <--Fedora5 or above (X-Server 1.3.x)
				#define	XORG_NEWVERS14		0  <--Fedora9 or above (X-Server 1.4.x or above)
				#define	XORG_NEWVERS110		0  <--Fedora15 or above (X-Server 1.10 or above�j
				#define	XORG_NEWVERS112		0  <--Fedora17 or above (X-Server 1.12 or above�j
				#define	CHG_SCR_RESOLUTION	1  <--Before Fedora8 (Before X-Server 1.3) or Fedora12
				#define ADJ_CALIB_DEFSCR	0  <---Fedora9-11
				#else
				  :
				#endif
					                   fc17-19  fc15-16 fc12-14 fc9-11 fc7/8  fc5/6
					-----------------------------------------------------------------
					XIRG_NEWVERS0         0        0       0      0     0      1
					XIRG_NEWVERS          1        1       1      1     1      1
					XIRG_NEWVERS14        1        1       1      1     0      0
					XIRG_NEWVERS110       1        1       0      0     0      0
					XIRG_NEWVERS112       1        0       0      0     0      0
					CHG_SCR_RESOLUTION    0        0       1      0     1      1
					ADJ_CALIB_DEFSCR      0        0       0      1     0      0
		(3-4)In src/Makefile
				DEFAULT_INCLUDES = -I. -I$(srcdir)....
			Add a pass of <TSC10LD_Vxxx>/driver
			Example)
			DEFAULT_INCLUDES = -I. -I$(srcdir).... -I/home/hoge/dmc/TSC10LD_V117/driver
		(3-5)You do "make" with a src directory.
				# make
		(3-6)Copy a made object.
				# cp .libs/dmc_drv.so /lib/xorg/modules/input

	------------------------------------------------
	driver (ubuntu = Use debian source)
	------------------------------------------------
		(1)Using apt-get, please install follows.
				xorg-dev
				xserver-xorg-dev
		(2)Please expand a source.
		   ubuntu8
			# apt-get source xserver-xorg-input-dmc
			:
			# tar xvzf xserver-xorg-input-dmc_X.X.X.tar.gz
			:
			# cd xf86-input-dmc-X.X.X
			# ./configure
			:
			#
		   ubuntu9
			"xserver-xorg-input-dmc" has disappeared in xorg1.6.
			Please use "xserver-xorg-input-dmc" which you can get on Ubuntu8.

		(3)Please copy the following files in src.
			<TSC10LD_Vxxx>/driver/cmd.h
			<TSC10LD_Vxxx>/driver/xf86DMC.h
			<TSC10LD_Vxxx>/driver/xf86DMC.c

		(4)Please change "#if 0" to "#if 1" in src/xf86DMC.c. (Same as 3-3)

		(5)In src/Makefile
			DEFAULT_INCLUDES = -I. -I$(srcdir)....
			Please add a pass of <TSC10LD_Vxxx/driver
		  (Example)
			DEFAULT_INCLUDES = -I. -I$(srcdir).... -I/home/hoge/dmc/TSC10LD_V116/driver

		(6)You do "make" with a src directory.
			# make

		(7)Copy a made object.
			# cp .libs/dmc_drv.so /lib/xorg/modules/input


***************************************************************************************
Remarks 3.  Method of compile of USB driver
***************************************************************************************
kernel2.4
	(1)Please install the kernel source. However, compile of the kernel is 
	   unnecessary.
	(2)It moves to TSC10LD_Vxxx/usb.
	(3)"makefile" is edited. Please set the pass of the INCLUDE source in makefile
	   by linux currently used.
		�F
		TARGET=usbdmc.o usbtest
			
		#LINUX=linux-2.4
		LINUX=linux�@�@�@�@�@�@�@<------Usually, this point is edited.
			
		INCLUDE= /usr/src/$(LINUX)/include
		#KCFLAGS= -D__KERNEL__ -I$(INCLUDE) -Wall -Wstrict-prototypes -O2 \
		#         -fomit-frame-pointer -pipe -DMODULE
		KCFLAGS=	-D__KERNEL__ \
					-I$(INCLUDE) \
			�F
	(4)It compiles.
		$ make clean all
	(5)If compile finishes correctly, it will be used loading.
		$ insmod tpdmc.o
		$ insmod usbdmc.o

		*You have to load the USB driver, before starting XWindow.

kernel2.6
	(1)Please install the kernel source.
	(2)It moves to TSC10LD_Vxxx/usb26.
	(3)"makefile" is edited. Please set the pass of the INCLUDE source in makefile
	   by linux currently used.
		�F
		TARGET:=usbdmc.ko
			
		KDIR=/usr/src/redhat/BUILD/kernel-2.6.9/linux-2.6.9  <------Usually,
							       	 this point is edited.
		CFLAGS+=-DKER26=1
		�F
		*In Fedora9 or above, please change CFLAGS to EXTRA_CFLAGS.
	(4)It compiles.
		$ make clean all
		*When an error occurs in compile, it may be necessary to compile 
		 the kernel itself once.
	(5)If compile finishes correctly, it will be used loading.
		$ insmod tpdmc.ko
		$ insmod usbdmc.ko
		*You have to load the USB driver, before starting XWindow.

***************************************************************************************
Remarks 4.  Uninstallation
***************************************************************************************
	Please execute the contrary of copy work in chapter 5 for uninstallation.
        Please delete the files stated as below and return the edited "XF86Config"
        to the original conditions.


	Except Fedora5/6
			Object                  Directory
			----------------------------------------------------------
			dmc_drv.o               /usr/X111R6/lib/modules/input
			tbctl                   /usr/X11R6/bin
			tbcalib                 /usr/X11R6/bin
			tbtest                  /usr/X11R6/bin
			tbselector              /usr/X11R6/bin
			dmc_calib.dat           /etc/X11

	Fedora5/6
			Object                  Directory
			----------------------------------------------------------
			dmc_drv.o               /usr/lib/xorg/modules/input
			tbctl                   /usr/bin
			tbcalib                 /usr/bin
			tbtest                  /usr/bin
			tbselector              /usr/bin
			dmc_calib.dat           /etc/X11

	Fedora7 or above
			Object                  Directory
			----------------------------------------------------------
			dmc_drv.so              /usr/lib/xorg/modules/input
			tbctl                   /usr/bin
			tbcalib                 /usr/bin
			tbtest                  /usr/bin
			tbselector              /usr/bin
			dmc_calib.dat           /etc/X11

		*This directory is in the condition where objinstall was used.
		 When you copied manually, please delete the file of that location.
                *Objinstall does not install the USB driver.

***************************************************************************************
Remarks 5.  Automatic start
***************************************************************************************
	In order to automatically start tbctl, tbselector, please follow the method
	below in case of GNOME. 
        If any other window manager is used, please follow each recommended method. 
        
        Example: Redhat8
                Menu
                   Select gnome->[Other applications]->[Personal settings]->[Session],
                   and then add tbctl and tbselector to [Automatic start program]
    
        Example: Vine2.6
                Menu 
                   Select gnome->[Program]->[Desktop settings]->[Session]->
                   [Session Property & Startup Program], and then add tbclt and 
                   tbselector to [Automatic start program]

***************************************************************************************
Remarks 6.  Connection test
***************************************************************************************
	It is the example of a connection test with touch screen controller.
	When making it operate from console or XWindow, without operating XWindow,
	it performs in the situation that there is no touch setting by XF86Config 
	setting.

	*Operate by root user.

	(1)RS-232C (tbctl/tpin.c)

	**Communication is not normal when this is not received.

		[root@localhost /root]# ./tpin /dev/ttyS0
		path=3 raw mode
		>> touch-panel test prog. open [/dev/ttyS0]
		in = $12                        .....It receives from the controller
						     at the time of OPEN.**
		                                <----<return>
		*** command ***
		  1:reset         2:specify
		  3:goto XYP      4:goto IDLE from XYP
		 10:read status  11:read eeprom
		1                               <----Item 1 is chosen.
		input = .....[1] 1
		OUT len=1 $55 
		write 1 22
		in = $06                        .....ACK(=0x06) is received.**
		                                <----<return>
		*** command ***
		  1:reset         2:specify
		  3:goto XYP      4:goto IDLE from XYP
		 10:read status  11:read eeprom
		2                               <----Item 2 is chosen.
		input = .....[2] 2
		OUT len=2 $5 $41 
		write 2 22
		in = $06                        .....ACK(=0x06) is received.**
		                                <----<return>
		*** command ***
		  1:reset         2:specify
		  3:goto XYP      4:goto IDLE from XYP
		 10:read status  11:read eeprom
		3                               <----Item 3 is chosen.
		input = .....[3] 3
		OUT len=1 $31 
		write 1 22
		     ......Coordinates will be displayed if touch input is carried out.
		PenDown:(x,y)=(642,536)=($0282,$0218) : $02 $82 $02 $18
		PenDown:(x,y)=(642,536)=($0282,$0218) : $02 $82 $02 $18
		PenDown:(x,y)=(642,536)=($0282,$0218) : $02 $82 $02 $18
		PenUp

	(2) USB�iusb/usbtest.c)
		[root@localhost usb]# insmod usbdmc.o
		Warning: loading usbdmc.o will taint the kernel: no license
		  See http://www.tux.org/lkml/#export-tainted for information about 
		  tainted modules
		Module usbdmc loaded, with warnings
		[root@localhost usb]# ./usbtest 3
		reset
		specify
		goto xyp
		ok
		get status 3190 
		read eeprom res 0
		goto xyp                        ......Waiting for touch input.
		     ......Coordinates will be displayed if touch input is carried out.
		Touch 11 ON  ( 884, 597)
		Touch 10 OFF ( 884, 597)
		Touch 11 ON  ( 890, 602)
		Touch 10 OFF ( 890, 602)

***************************************************************************************
Remarks 7.  xorg.conf configuration
***************************************************************************************
Input Device Configuration 

�EIdentifier
	ID (Same as Serverlayout)
�EDriver
	Driver Name ("dmc")
�EOption
	Types Of Options	Comment
	-----------------------------------------
	Device			Device Name
	USB			1= Specify a usb device
	SaveFile		File to save the setting data
	ReverseXY		1= Coorrect touch coordinates (X=1023-x, y=1023-y)
	SwapXY			1= Swap the touch X and Y coordinates
	ApiDir			PIPE name to communicate with the XINPUT driver

�EExample
	Section "InputDevice"
	    Identifier  "Touch"
	    Driver      "dmc"
	    Option      "USB"  "1"
	    Option      "Device"  "/dev/touch0"
	    Option      "SaveFile" "/etc/X11/dmc_calib.dat"
	    Option      "ApiDir" "/tmp"
	EndSection

***************************************************************************************
Remarks 8.  Compatibility
***************************************************************************************
The following cautions are required when upgrading from the versions up to V1.0.9.

	Calibration data in EEPROM
	   It does not have the compatibility from a former versions. It is necessary
	   to re-create with this version.

The following cautions are required when upgrading from V1.1.2.

         *Communication method between XINPUT driver and applications such as tbctl
                It does not have the compatibility from the former version. It is made
                to packet-communicate by using a pipe.
                Please specify the directory that creates the pipe by using ApiDir in 
                "XF86Config".  

	 *USB filter driver
                In order to achieve PnP function, the USB filter driver is intervened 
                between the USB driver and XINPUT driver. 
                Please change "Device" in Input Device section in "XF86Config" to 
                "/dev/touch0". 

***************************************************************************************
Remarks 9.  Attention in FedoraCore 7
***************************************************************************************
The following attention is necessary when you install usb driver on FedoraCore7.
	The usb driver does not work unless you delete the following and reboot.
		/lib/modules/2.6.xxx/kernel/drivers/usb/input/usbtouchscreen.so


***************************************************************************************
Remarks 10.  RS-232C connection
***************************************************************************************
For V2.0.4 and above
	If a communication cable was not connected at the time of system start up, 
	you were not able to use touch screen.
	In V2.0.4 and above, when you connect a communication cable and input of power
	supply of TSC after a system started up, you can use touch screen.
	When a power supply is input, TSC outputs 12h. When a TSC-10/LD receives 12h,
	it initializes TSC series IC.
	Thus TSC-10/LD recognizes TSC.





Copyright (C) 2005-2014 DMC Co., Ltd
	Permission is hereby granted, free of charge, to any person obtaining a
	copy of this software and associated documentation files (the "Software"),
	to deal in the Software without restriction, including without limitation
	the rights to use, copy, modify, merge, publish, distribute, sublicense,
	and/or sell copies of the Software, and to permit persons to whom the
	Software is furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in
	all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
	THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
	WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
	OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
	SOFTWARE.

	Except as contained in this notice, the name of the DMC Co., Ltd shall not 
	be used in advertising or otherwise to promote the sale, use or other dealings
	in this Software without prior written authorization from DMC Co., Ltd.





This document can be freely distributed, but any alternation to this document is prohibited.
